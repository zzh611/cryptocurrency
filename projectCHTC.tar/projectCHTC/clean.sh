#!/bin/bash

rm -f log/* output/* error/*  interactive.log
exit 0
