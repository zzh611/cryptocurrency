#!/bin/bash

ls data | cut -d'.' -f1 > filename.txt
